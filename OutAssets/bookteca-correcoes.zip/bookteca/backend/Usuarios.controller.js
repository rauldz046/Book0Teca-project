const bcrypt = require("bcrypt"); // ← IMPORTAÇÃO QUE ESTAVA FALTANDO
const Usuario = require("../models/Usuarios");
const Status = require("../models/StatusAtividadeGeral");
const InfoEndereco = require("../models/InfoEndereco");
const InfoBancario = require("../models/InfoBancario");

const controller = {};

/* CREATE */
controller.UsuariosCreate = async (req, res) => {
  const data = req.body;

  try {
    const senhaHash = await bcrypt.hash(data.Senha, 10);

    const user = await Usuario.create({
      Nome: data.Nome,
      CPF: data.CPF,
      Telefone: data.Telefone,
      Senha: senhaHash,
      Email: data.Email,
      SenhaInicial: true,
      Status: data.Status ?? 1,
      InfoEndereco: data.InfoEndereco,
      InfoBancario: data.InfoBancario,
    });

    // Não retorna a senha no response
    const { Senha, ...userSemSenha } = user.toJSON();
    res.status(201).json(userSemSenha);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/* LOGIN — compara senha com hash */
controller.loginValidation = async (req, res) => {
  const { email, senha } = req.body;

  try {
    const user = await Usuario.findOne({
      where: { Email: email },
    });

    if (!user) {
      return res.status(401).json({ message: "E-mail ou senha incorretos" });
    }

    const senhaCorreta = await bcrypt.compare(senha, user.Senha);
    if (!senhaCorreta) {
      return res.status(401).json({ message: "E-mail ou senha incorretos" });
    }

    const { Senha, ...userSemSenha } = user.toJSON();
    return res.status(200).json(userSemSenha);
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
};

/* GET ALL */
controller.getUsers = async (req, res) => {
  try {
    const users = await Usuario.findAll({
      attributes: { exclude: ["Senha"] },
      include: [
        { model: Status, as: "statusInfo", attributes: ["Descricao"] },
        { model: InfoEndereco, as: "endereco" },
        { model: InfoBancario, as: "banco" },
      ],
    });

    return res.status(200).json(users);
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
};

/* GET BY ID */
controller.getUserById = async (req, res) => {
  try {
    const user = await Usuario.findByPk(req.params.id, {
      attributes: { exclude: ["Senha"] },
    });

    if (!user) return res.status(404).json({ message: "Usuário não encontrado" });

    return res.status(200).json(user);
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
};

/* UPDATE STATUS — corrigido o bug "resres" */
controller.updateStatus = async (req, res) => {
  const data = req.body;

  try {
    const newStatus = await Status.findOne({
      where: { Descricao: data.Descricao },
    });

    if (!newStatus) {
      return res.status(404).json({ message: "Status não encontrado" });
    }

    await Usuario.update(
      { Status: newStatus.idStatus },
      { where: { idUsuario: data.idUsuario } }
    );

    return res.status(200).json({ message: "Status atualizado" }); // ← "resres" corrigido
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
};

/* UPDATE USER */
controller.updateUser = async (req, res) => {
  const data = req.body;

  try {
    await Usuario.update(
      {
        Nome: data.Nome,
        Telefone: data.Telefone,
        Email: data.Email,
        fotoperfil: data.fotoperfil,
      },
      { where: { idUsuario: data.idUsuario } }
    );

    return res.status(200).json({ message: "Usuário atualizado" });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
};

/* UPDATE PASSWORD */
controller.updatePassword = async (req, res) => {
  const data = req.body;

  try {
    const senhaHash = await bcrypt.hash(data.Senha, 10);

    await Usuario.update(
      { Senha: senhaHash, SenhaInicial: false },
      { where: { idUsuario: data.idUsuario } }
    );

    return res.status(200).json({ message: "Senha atualizada" });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
};

/* DELETE (soft delete via paranoid) */
controller.deleteUser = async (req, res) => {
  const { idUsuario } = req.body;

  try {
    const user = await Usuario.findByPk(idUsuario);
    if (!user) return res.status(404).json({ message: "Usuário não encontrado" });

    await user.destroy(); // paranoid: true — faz soft delete automaticamente
    return res.status(200).json({ message: "Usuário removido" });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
};

module.exports = controller;
