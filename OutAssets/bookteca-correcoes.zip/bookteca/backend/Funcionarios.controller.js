const bcrypt = require("bcrypt"); // ← IMPORTAÇÃO QUE ESTAVA FALTANDO
const Funcionario = require("../models/Funcionarios");
const Status = require("../models/StatusAtividadeGeral");
const InfoEndereco = require("../models/InfoEndereco");
const InfoBancario = require("../models/InfoBancario");
const PerfilFuncionario = require("../models/PerfilFuncionarios");

const controller = {};

/* CREATE */
controller.FuncionariosCreate = async (req, res) => {
  const data = req.body;

  try {
    const senhaHash = await bcrypt.hash(data.SenhaFunc, 10);

    const funcionario = await Funcionario.create({
      MatriculaFunc: data.MatriculaFunc,
      NomeFunc: data.NomeFunc,
      CPFFunc: data.CPFFunc,
      EmailFunc: data.EmailFunc,
      RegiaoFunc: data.RegiaoFunc,
      SenhaFunc: senhaHash,
      SenhaInicialFunc: true,
      CadastradoPor: data.CadastradoPor,
      idPerfilFuncionarios: data.idPerfilFuncionarios,
      StatusAtividadeGeral_idStatus: data.StatusAtividadeGeral_idStatus ?? 1,
      InfoBancario_IdInfoBancario: data.InfoBancario_IdInfoBancario,
      InfoEndereco_idInfoEnd: data.InfoEndereco_idInfoEnd,
    });

    const { SenhaFunc, ...funcSemSenha } = funcionario.toJSON();
    res.status(201).json(funcSemSenha);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/* LOGIN — compara senha com hash e retorna perfil */
controller.loginValidation = async (req, res) => {
  const { email, senha } = req.body;

  try {
    const funcionario = await Funcionario.findOne({
      where: { EmailFunc: email },
      include: [
        { model: PerfilFuncionario, as: "perfil", attributes: ["idPerfil", "Descricao"] },
      ],
    });

    if (!funcionario) {
      return res.status(401).json({ message: "E-mail ou senha incorretos" });
    }

    const senhaCorreta = await bcrypt.compare(senha, funcionario.SenhaFunc);
    if (!senhaCorreta) {
      return res.status(401).json({ message: "E-mail ou senha incorretos" });
    }

    const { SenhaFunc, ...funcSemSenha } = funcionario.toJSON();
    return res.status(200).json(funcSemSenha);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/* GET ALL */
controller.getFuncionarios = async (req, res) => {
  try {
    const funcionarios = await Funcionario.findAll({
      attributes: { exclude: ["SenhaFunc"] },
      include: [
        { model: Status, as: "statusInfo", attributes: ["Descricao"] },
        { model: InfoEndereco, as: "endereco" },
        { model: InfoBancario, as: "banco" },
        { model: PerfilFuncionario, as: "perfil" },
      ],
    });

    res.status(200).json(funcionarios);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/* UPDATE */
controller.updateFuncionario = async (req, res) => {
  const data = req.body;

  try {
    await Funcionario.update(
      {
        NomeFunc: data.NomeFunc,
        EmailFunc: data.EmailFunc,
        RegiaoFunc: data.RegiaoFunc,
        CPFFunc: data.CPFFunc,
      },
      { where: { idFuncionario: data.idFuncionario } }
    );

    res.status(200).json({ message: "Funcionário atualizado" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/* UPDATE PASSWORD */
controller.updatePassword = async (req, res) => {
  const data = req.body;

  try {
    const senhaHash = await bcrypt.hash(data.SenhaFunc, 10);

    await Funcionario.update(
      { SenhaFunc: senhaHash, SenhaInicialFunc: false },
      { where: { idFuncionario: data.idFuncionario } }
    );

    res.status(200).json({ message: "Senha atualizada" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/* UPDATE STATUS */
controller.updateStatus = async (req, res) => {
  const data = req.body;

  try {
    const newStatus = await Status.findOne({
      where: { Descricao: data.Descricao },
    });

    if (!newStatus) {
      return res.status(404).json({ message: "Status não encontrado" });
    }

    await Funcionario.update(
      { StatusAtividadeGeral_idStatus: newStatus.idStatus },
      { where: { idFuncionario: data.idFuncionario } }
    );

    res.status(200).json({ message: "Status atualizado" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/* DELETE (soft delete via paranoid) */
controller.deleteFuncionario = async (req, res) => {
  const { idFuncionario } = req.body;

  try {
    const func = await Funcionario.findByPk(idFuncionario);
    if (!func) return res.status(404).json({ message: "Funcionário não encontrado" });

    await func.destroy();
    res.status(200).json({ message: "Funcionário removido" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = controller;
