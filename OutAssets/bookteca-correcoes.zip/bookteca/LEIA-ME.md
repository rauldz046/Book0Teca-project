# Book0Teca — Arquivos Gerados

## Como aplicar

---

## FRONT-END (`front-end/src/app/`)

### 1. Criar pasta `core/` dentro de `src/app/`

```
src/app/core/
├── services/
│   └── auth.service.ts          ← NOVO
├── guards/
│   ├── auth.guard.ts            ← NOVO
│   └── role.guard.ts            ← NOVO
└── interceptors/
    └── auth.interceptor.ts      ← NOVO
```

### 2. Substituir arquivos existentes

| Arquivo gerado               | Destino no projeto                                          |
|------------------------------|-------------------------------------------------------------|
| `app-routing.module.ts`      | `src/app/app-routing.module.ts`                             |
| `app.module.ts`              | `src/app/app.module.ts`                                     |
| `app.component.ts`           | `src/app/app.component.ts`                                  |
| `auth-login.component.ts`    | `src/app/pages/auth-login/auth-login.component.ts`          |
| `nav.component.ts`           | `src/app/componentes/nav/nav.component.ts`                  |

### 3. Criar novo componente

Crie a pasta e os arquivos:
```
src/app/pages/acesso-negado/
└── acesso-negado.component.ts   ← NOVO (inline template, não precisa de .html)
```

---

## BACK-END (`back-end/`)

### 1. Instalar dependências que faltavam

```bash
cd back-end
npm install bcrypt jsonwebtoken
```

### 2. Substituir controllers

| Arquivo gerado                 | Destino no projeto                                    |
|--------------------------------|-------------------------------------------------------|
| `Usuarios.controller.js`       | `back-end/controllers/Usuarios.controller.js`         |
| `Funcionarios.controller.js`   | `back-end/controllers/Funcionarios.controller.js`     |
| `package.json`                 | `back-end/package.json`                               |

---

## Bugs corrigidos nesta entrega

1. **`bcrypt` não importado** nos dois controllers → adicionado `require('bcrypt')`
2. **`resres`** no `updateStatus` de Usuários → corrigido para `res`
3. **Login sem hash** → agora usa `bcrypt.compare()` para verificar a senha
4. **Sessão não salva** após login → `AuthService` persiste no `localStorage`
5. **Perfil hardcoded** no Nav → agora lê do `AuthService`
6. **Rotas sem proteção** → `authGuard` e `roleGuard` em todas as rotas
7. **Interceptor ausente** → token enviado automaticamente em todas requisições

---

## Fluxo de autenticação após as correções

```
Login → AuthService.loginUsuario() ou loginFuncionario()
      → API retorna dados do usuário
      → AuthService salva SessaoUsuario no localStorage
      → NavComponent lê perfil via auth.perfil
      → Guards verificam auth.estaLogado + auth.temPermissao()
      → Interceptor injeta token em todas as requisições HTTP
```
