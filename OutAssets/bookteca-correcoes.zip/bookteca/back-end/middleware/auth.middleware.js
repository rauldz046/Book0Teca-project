const jwt = require('jsonwebtoken');

const SECRET = process.env.JWT_SECRET || 'bookteca_secret_dev';

/**
 * Middleware que verifica o token JWT no header Authorization.
 * Adiciona req.usuarioLogado com id, tipo e perfil do usuário autenticado.
 *
 * Uso nas rotas:
 *   router.get('/findAll', authMiddleware, controller.getUsers);
 *
 * Rotas públicas (login, create) NÃO devem usar este middleware.
 */
const authMiddleware = (req, res, next) => {
  const authHeader = req.headers['authorization'];

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Token não fornecido.' });
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, SECRET);
    req.usuarioLogado = decoded; // { id, tipo, perfil, iat, exp }
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Token inválido ou expirado.' });
  }
};

/**
 * Middleware de verificação de perfil.
 * Use depois de authMiddleware.
 *
 * Uso:
 *   router.get('/findAll', authMiddleware, roleMiddleware(['BIBLIOTECARIO']), controller.getUsers);
 */
const roleMiddleware = (perfisPermitidos = []) => {
  return (req, res, next) => {
    const { perfil } = req.usuarioLogado || {};

    if (!perfil) {
      return res.status(403).json({ message: 'Perfil não identificado.' });
    }

    if (perfil === 'ADMINISTRADOR' || perfisPermitidos.includes(perfil)) {
      return next();
    }

    return res.status(403).json({ message: 'Acesso negado para este perfil.' });
  };
};

module.exports = { authMiddleware, roleMiddleware };
