const bcrypt = require('bcrypt'); // ← CORREÇÃO: estava faltando
const jwt = require('jsonwebtoken');
const Usuario = require('../models/Usuarios');
const Status = require('../models/StatusAtividadeGeral');
const InfoEndereco = require('../models/InfoEndereco');
const InfoBancario = require('../models/InfoBancario');

const SECRET = process.env.JWT_SECRET || 'bookteca_secret_dev';
const SALT_ROUNDS = 10;

const controller = {};

/* ─── CREATE ─────────────────────────────────────────────────────── */
controller.UsuariosCreate = async (req, res) => {
  const data = req.body;
  try {
    const senhaHash = await bcrypt.hash(data.Senha, SALT_ROUNDS);
    const user = await Usuario.create({
      Nome: data.Nome,
      CPF: data.CPF,
      Telefone: data.Telefone,
      Senha: senhaHash,
      Email: data.Email,
      SenhaInicial: data.SenhaInicial ?? true,
      Status: data.Status ?? 1,
      InfoEndereco: data.InfoEndereco ?? null,
      InfoBancario: data.InfoBancario ?? null,
      created_at: new Date(),
      updated_at: new Date(),
    });

    // Não retorna a senha
    const { Senha, ...userSemSenha } = user.toJSON();
    res.status(201).json(userSemSenha);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/* ─── LOGIN ─────────────────────────────────────────────────────── */
controller.loginValidation = async (req, res) => {
  const { email, senha } = req.body;
  try {
    const user = await Usuario.findOne({
      where: { Email: email },
      include: [
        { model: Status, as: 'statusInfo', attributes: ['Descricao'] },
      ],
    });

    if (!user) {
      return res.status(401).json({ message: 'E-mail ou senha incorretos.' });
    }

    // Compara senha com hash — CORREÇÃO: antes comparava em texto puro
    const senhaCorreta = await bcrypt.compare(senha, user.Senha);
    if (!senhaCorreta) {
      return res.status(401).json({ message: 'E-mail ou senha incorretos.' });
    }

    // Gera JWT com perfil LEITOR para usuários comuns
    const token = jwt.sign(
      { id: user.idUsuario, tipo: 'usuario', perfil: 'LEITOR' },
      SECRET,
      { expiresIn: '8h' }
    );

    const { Senha, ...userSemSenha } = user.toJSON();
    return res.status(200).json({ ...userSemSenha, token });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
};

/* ─── GET ALL ────────────────────────────────────────────────────── */
controller.getUsers = async (req, res) => {
  try {
    const users = await Usuario.findAll({
      attributes: { exclude: ['Senha'] },
      include: [
        { model: Status, as: 'statusInfo', attributes: ['Descricao'] },
        { model: InfoEndereco, as: 'endereco' },
        { model: InfoBancario, as: 'banco' },
      ],
    });
    return res.status(200).json(users);
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
};

/* ─── GET BY ID ──────────────────────────────────────────────────── */
controller.getUserById = async (req, res) => {
  try {
    const user = await Usuario.findByPk(req.params.id, {
      attributes: { exclude: ['Senha'] },
    });
    if (!user) return res.status(404).json({ message: 'Usuário não encontrado.' });
    return res.status(200).json(user);
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
};

/* ─── UPDATE ─────────────────────────────────────────────────────── */
controller.updateUser = async (req, res) => {
  const data = req.body;
  try {
    await Usuario.update(
      {
        Nome: data.Nome,
        Telefone: data.Telefone,
        Email: data.Email,
        updated_at: new Date(),
      },
      { where: { idUsuario: data.idUsuario } }
    );
    return res.status(200).json({ message: 'Atualizado com sucesso.' });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
};

/* ─── UPDATE PASSWORD ────────────────────────────────────────────── */
controller.updatePassword = async (req, res) => {
  const data = req.body;
  try {
    const senhaHash = await bcrypt.hash(data.Senha, SALT_ROUNDS);
    await Usuario.update(
      { Senha: senhaHash, updated_at: new Date() },
      { where: { idUsuario: data.idUsuario } }
    );
    return res.status(200).json({ message: 'Senha atualizada.' });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
};

/* ─── UPDATE STATUS ─────────────────────────────────────────────── */
controller.updateStatus = async (req, res) => {
  const data = req.body;
  try {
    const newStatus = await Status.findOne({
      where: { Descricao: data.Descricao },
    });

    if (!newStatus) {
      return res.status(404).json({ message: 'Status não encontrado.' });
    }

    await Usuario.update(
      { Status: newStatus.idStatus, updated_at: new Date() },
      { where: { idUsuario: data.idUsuario } }
    );

    return res.status(200).json({ message: 'Status atualizado.' }); // ← CORREÇÃO: era "resres"
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
};

/* ─── DELETE (SOFT) ──────────────────────────────────────────────── */
controller.deleteUser = async (req, res) => {
  const data = req.body;
  try {
    await Usuario.destroy({
      where: { idUsuario: data.idUsuario },
    });
    return res.status(200).json({ message: 'Usuário removido.' });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
};

module.exports = controller;
