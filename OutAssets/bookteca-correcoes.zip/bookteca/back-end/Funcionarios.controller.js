const bcrypt = require('bcrypt'); // ← CORREÇÃO: estava faltando
const jwt = require('jsonwebtoken');
const Funcionario = require('../models/Funcionarios');
const Status = require('../models/StatusAtividadeGeral');
const InfoEndereco = require('../models/InfoEndereco');
const InfoBancario = require('../models/InfoBancario');
const PerfilFuncionario = require('../models/PerfilFuncionarios');

const SECRET = process.env.JWT_SECRET || 'bookteca_secret_dev';
const SALT_ROUNDS = 10;

const controller = {};

/* ─── CREATE ─────────────────────────────────────────────────────── */
controller.FuncionariosCreate = async (req, res) => {
  const data = req.body;
  try {
    const senhaHash = await bcrypt.hash(data.SenhaFunc, SALT_ROUNDS);
    const funcionario = await Funcionario.create({
      MatriculaFunc: data.MatriculaFunc,
      NomeFunc: data.NomeFunc,
      CPFFunc: data.CPFFunc,
      EmailFunc: data.EmailFunc,
      RegiaoFunc: data.RegiaoFunc,
      SenhaFunc: senhaHash,
      SenhaInicialFunc: data.SenhaInicialFunc ?? true,
      CadastradoPor: data.CadastradoPor ?? null,
      idPerfilFuncionarios: data.idPerfilFuncionarios,
      StatusAtividadeGeral_idStatus: data.StatusAtividadeGeral_idStatus ?? 1,
      InfoBancario_IdInfoBancario: data.InfoBancario_IdInfoBancario ?? null,
      InfoEndereco_idInfoEnd: data.InfoEndereco_idInfoEnd ?? null,
      created_date: new Date(),
      update_date: new Date(),
    });

    const { SenhaFunc, ...funcSemSenha } = funcionario.toJSON();
    res.status(201).json(funcSemSenha);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/* ─── LOGIN ─────────────────────────────────────────────────────── */
controller.loginValidation = async (req, res) => {
  const { email, senha } = req.body;
  try {
    const funcionario = await Funcionario.findOne({
      where: { EmailFunc: email },
      include: [
        { model: PerfilFuncionario, as: 'perfil', attributes: ['Descricao'] },
        { model: Status, as: 'statusInfo', attributes: ['Descricao'] },
      ],
    });

    if (!funcionario) {
      return res.status(401).json({ message: 'E-mail ou senha incorretos.' });
    }

    const senhaCorreta = await bcrypt.compare(senha, funcionario.SenhaFunc);
    if (!senhaCorreta) {
      return res.status(401).json({ message: 'E-mail ou senha incorretos.' });
    }

    // Mapeia o perfil do banco para o enum do sistema
    const descricaoPerfil = funcionario.perfil?.Descricao?.toUpperCase() ?? 'BIBLIOTECARIO';
    const perfilMap = {
      BIBLIOTECARIO: 'BIBLIOTECARIO',
      FINANCEIRO: 'FINANCEIRO',
      ESTOQUE: 'ESTOQUE',
      ADMINISTRADOR: 'ADMINISTRADOR',
    };
    const perfil = perfilMap[descricaoPerfil] ?? 'BIBLIOTECARIO';

    const token = jwt.sign(
      { id: funcionario.idFuncionario, tipo: 'funcionario', perfil },
      SECRET,
      { expiresIn: '8h' }
    );

    const { SenhaFunc, ...funcSemSenha } = funcionario.toJSON();
    return res.status(200).json({ ...funcSemSenha, token });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/* ─── GET ALL ────────────────────────────────────────────────────── */
controller.getFuncionarios = async (req, res) => {
  try {
    const funcionarios = await Funcionario.findAll({
      attributes: { exclude: ['SenhaFunc'] },
      include: [
        { model: Status, as: 'statusInfo', attributes: ['Descricao'] },
        { model: InfoEndereco, as: 'endereco' },
        { model: InfoBancario, as: 'banco' },
        { model: PerfilFuncionario, as: 'perfil' },
      ],
    });
    res.status(200).json(funcionarios);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/* ─── UPDATE ─────────────────────────────────────────────────────── */
controller.updateFuncionario = async (req, res) => {
  const data = req.body;
  try {
    await Funcionario.update(
      {
        NomeFunc: data.NomeFunc,
        EmailFunc: data.EmailFunc,
        RegiaoFunc: data.RegiaoFunc,
        update_date: new Date(),
      },
      { where: { idFuncionario: data.idFuncionario } }
    );
    res.status(200).json({ message: 'Atualizado com sucesso.' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/* ─── UPDATE PASSWORD ────────────────────────────────────────────── */
controller.updatePassword = async (req, res) => {
  const data = req.body;
  try {
    const senhaHash = await bcrypt.hash(data.SenhaFunc, SALT_ROUNDS);
    await Funcionario.update(
      { SenhaFunc: senhaHash, update_date: new Date() },
      { where: { idFuncionario: data.idFuncionario } }
    );
    res.status(200).json({ message: 'Senha atualizada.' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/* ─── UPDATE STATUS ──────────────────────────────────────────────── */
controller.updateStatus = async (req, res) => {
  const data = req.body;
  try {
    const newStatus = await Status.findOne({
      where: { Descricao: data.Descricao },
    });

    if (!newStatus) {
      return res.status(404).json({ message: 'Status não encontrado.' });
    }

    await Funcionario.update(
      { StatusAtividadeGeral_idStatus: newStatus.idStatus, update_date: new Date() },
      { where: { idFuncionario: data.idFuncionario } }
    );
    res.status(200).json({ message: 'Status atualizado.' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/* ─── DELETE (SOFT) ──────────────────────────────────────────────── */
controller.deleteFuncionario = async (req, res) => {
  const data = req.body;
  try {
    await Funcionario.destroy({
      where: { idFuncionario: data.idFuncionario },
    });
    res.status(200).json({ message: 'Funcionário removido.' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = controller;
