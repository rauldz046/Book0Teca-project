import { Component, inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/api';
import { trigger, transition, style, animate } from '@angular/animations';
import { ClientesService } from 'src/app/services/Clientes.service';
import { AlertService } from 'src/app/utils/toast-alert-service.service';

@Component({
  selector: 'app-sign-in-form-user',
  templateUrl: './sign-in-form-user.component.html',
  styleUrls: ['./sign-in-form-user.component.scss'],
  animations: [
    trigger('stepAnimation', [
      transition(':enter', [
        style({ opacity: 0, transform: 'translateX(30px)' }),
        animate('400ms ease-out', style({ opacity: 1, transform: 'translateX(0)' })),
      ]),
      transition(':leave', [
        animate('400ms ease-in', style({ opacity: 0, transform: 'translateX(-30px)' })),
      ]),
    ]),
  ],
})
export class SignInFormUserComponent implements OnInit {
  private fb = inject(FormBuilder);
  private router = inject(Router);
  private clienteService = inject(ClientesService);
  private alert = inject(AlertService);

  registerForm!: FormGroup;
  activeIndex: number = 0;
  items: MenuItem[] = [];
  isLoading = false;

  ngOnInit() {
    this.items = [
      { label: 'Perfil' },
      { label: 'Endereço' },
      { label: 'Financeiro' },
    ];

    this.registerForm = new FormGroup({
      // Dados pessoais (obrigatórios)
      nome: new FormControl('', [Validators.required, Validators.minLength(3)]),
      cpf: new FormControl('', [Validators.required]),
      telefone: new FormControl('', [Validators.required]),
      email: new FormControl('', [Validators.required, Validators.email]),
      senha: new FormControl('', [Validators.required, Validators.minLength(6)]),

      // Endereço (opcional)
      logradouro: new FormControl(''),
      bairro: new FormControl(''),
      numero: new FormControl(''),
      cidade: new FormControl(''),
      estado: new FormControl(''),
      cep: new FormControl(''),
      nacionalidade: new FormControl('Brasileiro'),
      complemento: new FormControl(''),

      // Bancário (opcional)
      nomeBanco: new FormControl(''),
      codigoBanco: new FormControl(''),
      tipoConta: new FormControl(''),
      numeroAgencia: new FormControl(''),
      digitoAgencia: new FormControl(''),
      numeroConta: new FormControl(''),
      digitoConta: new FormControl(''),
      codigoPix: new FormControl(''),
    });
  }

  nextStep() {
    if (this.activeIndex === 0 && this.stepUmInvalido()) {
      this.registerForm.get('nome')?.markAsTouched();
      this.registerForm.get('email')?.markAsTouched();
      this.registerForm.get('cpf')?.markAsTouched();
      this.registerForm.get('senha')?.markAsTouched();
      this.alert.toastWarning('Preencha todos os campos obrigatórios.');
      return;
    }
    if (this.activeIndex < 2) this.activeIndex++;
  }

  prevStep() {
    if (this.activeIndex > 0) this.activeIndex--;
  }

  pularEtapa() {
    if (this.activeIndex === 2) {
      this.submit();
    } else {
      this.activeIndex++;
    }
  }

  private stepUmInvalido(): boolean {
    const campos = ['nome', 'email', 'cpf', 'senha'];
    return campos.some((c) => this.registerForm.get(c)?.invalid);
  }

  submit() {
    if (this.stepUmInvalido()) {
      this.alert.toastWarning('Preencha os dados obrigatórios antes de finalizar.');
      this.activeIndex = 0;
      return;
    }

    this.isLoading = true;
    const dados = this.registerForm.getRawValue();

    const payload = {
      Nome: dados.nome,
      CPF: dados.cpf,
      Telefone: dados.telefone,
      Email: dados.email,
      Senha: dados.senha,
      SenhaInicial: true,
      Status: 1,
      InfoEndereco: null,
      InfoBancario: null,
    };

    this.clienteService.CriarUsuario(payload).subscribe({
      next: () => {
        this.isLoading = false;
        this.alert.success('Conta criada!', 'Você já pode fazer login.');
        this.router.navigate(['/auth/log-in']);
      },
      error: (err) => {
        this.isLoading = false;
        this.alert.error('Erro ao criar conta', err?.error?.message ?? 'Tente novamente.');
      },
    });
  }
}
