import { Component, inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { AlertService } from 'src/app/utils/toast-alert-service.service';

@Component({
  selector: 'app-auth-login',
  templateUrl: './auth-login.component.html',
  styleUrls: ['./auth-login.component.scss'],
})
export class AuthLoginComponent implements OnInit {
  private router = inject(Router);
  private auth = inject(AuthService);
  private alert = inject(AlertService);

  isLoading = false;

  form: FormGroup = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    senha: new FormControl('', [Validators.required, Validators.minLength(4)]),
  });

  ngOnInit(): void {}

  goToSignIn() {
    this.router.navigate(['auth/sign-in']);
  }

  submit() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.alert.toastWarning('Preencha e-mail e senha corretamente.');
      return;
    }

    this.isLoading = true;
    const { email, senha } = this.form.getRawValue();

    // Tenta login como usuário (leitor) primeiro
    this.auth.loginUsuario(email, senha).subscribe({
      next: (res) => {
        this.isLoading = false;
        if (res) {
          this.alert.toastSuccess(`Bem-vindo, ${res.Nome}!`);
          this.router.navigate(['/home']);
        } else {
          // Usuário não encontrado → tenta como funcionário
          this.tentarLoginFuncionario(email, senha);
        }
      },
      error: () => {
        // Erro HTTP na rota de usuário → tenta funcionário
        this.tentarLoginFuncionario(email, senha);
      },
    });
  }

  private tentarLoginFuncionario(email: string, senha: string) {
    this.auth.loginFuncionario(email, senha).subscribe({
      next: (res) => {
        this.isLoading = false;
        if (res) {
          this.alert.toastSuccess(`Bem-vindo, ${res.NomeFunc}!`);
          this.router.navigate(['/home']);
        } else {
          this.alert.error('Acesso negado', 'E-mail ou senha incorretos.');
        }
      },
      error: (err) => {
        this.isLoading = false;
        this.alert.error('Falha no Login', 'E-mail ou senha incorretos.');
      },
    });
  }
}
