import { Component, inject, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { AlertService } from 'src/app/utils/toast-alert-service.service';

interface Emprestimo {
  id: number;
  livroTitulo: string;
  livroAutor: string;
  livroImagem: string;
  dataEmprestimo: Date;
  dataDevolucao: Date;
  status: 'EM_DIA' | 'ATRASADO' | 'DEVOLVIDO';
  diasRestantes?: number;
  multa?: number;
}

@Component({
  selector: 'app-emprestimos-usuarios',
  templateUrl: './emprestimos-usuarios.component.html',
  styleUrls: ['./emprestimos-usuarios.component.scss'],
})
export class EmprestimosUsuariosComponent implements OnInit {
  private auth = inject(AuthService);
  private alert = inject(AlertService);

  emprestimos: Emprestimo[] = [];
  loading = true;
  tabAtiva: 'ativos' | 'historico' = 'ativos';

  get emprestimosAtivos() {
    return this.emprestimos.filter((e) => e.status !== 'DEVOLVIDO');
  }

  get historico() {
    return this.emprestimos.filter((e) => e.status === 'DEVOLVIDO');
  }

  ngOnInit(): void {
    this.carregarEmprestimos();
  }

  carregarEmprestimos(): void {
    this.loading = true;
    // TODO: substituir por chamada real ao service de empréstimos
    setTimeout(() => {
      this.emprestimos = [
        {
          id: 1,
          livroTitulo: 'Dom Casmurro',
          livroAutor: 'Machado de Assis',
          livroImagem: 'https://m.media-amazon.com/images/I/71C7NInW3tL.jpg',
          dataEmprestimo: new Date('2026-03-01'),
          dataDevolucao: new Date('2026-03-15'),
          status: 'ATRASADO',
          diasRestantes: -12,
          multa: 6.0,
        },
        {
          id: 2,
          livroTitulo: 'O Alquimista',
          livroAutor: 'Paulo Coelho',
          livroImagem: 'https://m.media-amazon.com/images/I/81S6-M8W8iL.jpg',
          dataEmprestimo: new Date('2026-03-10'),
          dataDevolucao: new Date('2026-04-10'),
          status: 'EM_DIA',
          diasRestantes: 14,
        },
      ];
      this.loading = false;
    }, 800);
  }

  renovar(emprestimo: Emprestimo): void {
    if (emprestimo.status === 'ATRASADO') {
      this.alert.toastWarning('Não é possível renovar um empréstimo em atraso.');
      return;
    }
    this.alert.toastSuccess(`Empréstimo de "${emprestimo.livroTitulo}" renovado!`);
    emprestimo.dataDevolucao = new Date(
      emprestimo.dataDevolucao.getTime() + 14 * 24 * 60 * 60 * 1000
    );
  }

  getStatusLabel(status: string): string {
    const map: Record<string, string> = {
      EM_DIA: 'Em dia',
      ATRASADO: 'Atrasado',
      DEVOLVIDO: 'Devolvido',
    };
    return map[status] ?? status;
  }

  getSeverity(status: string): string {
    const map: Record<string, string> = {
      EM_DIA: 'success',
      ATRASADO: 'danger',
      DEVOLVIDO: 'info',
    };
    return map[status] ?? 'info';
  }
}
