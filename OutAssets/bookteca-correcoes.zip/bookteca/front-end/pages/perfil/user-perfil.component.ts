import { Component, inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService, SessaoUsuario } from 'src/app/services/auth.service';
import { ClientesService } from 'src/app/services/Clientes.service';
import { AlertService } from 'src/app/utils/toast-alert-service.service';

@Component({
  selector: 'app-user-perfil',
  templateUrl: './user-perfil.component.html',
  styleUrls: ['./user-perfil.component.scss'],
})
export class UserPerfilComponent implements OnInit {
  private auth = inject(AuthService);
  private clienteService = inject(ClientesService);
  private alert = inject(AlertService);

  sessao: SessaoUsuario | null = null;
  isLoading = false;
  editando = false;

  form = new FormGroup({
    nome: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required, Validators.email]),
    telefone: new FormControl(''),
  });

  senhaForm = new FormGroup({
    senhaAtual: new FormControl('', [Validators.required]),
    novaSenha: new FormControl('', [Validators.required, Validators.minLength(6)]),
    confirmarSenha: new FormControl('', [Validators.required]),
  });

  get perfilLabel(): string {
    const map: Record<string, string> = {
      LEITOR: 'Leitor',
      BIBLIOTECARIO: 'Bibliotecário',
      FINANCEIRO: 'Financeiro',
      ESTOQUE: 'Estoque',
      ADMINISTRADOR: 'Administrador',
    };
    return map[this.sessao?.perfil ?? ''] ?? 'Usuário';
  }

  ngOnInit(): void {
    this.sessao = this.auth.sessaoAtual;
    if (this.sessao) {
      this.form.patchValue({
        nome: this.sessao.nome,
        email: this.sessao.email,
      });
    }
  }

  salvarPerfil(): void {
    if (this.form.invalid) {
      this.alert.toastWarning('Preencha os campos corretamente.');
      return;
    }

    this.isLoading = true;
    const dados = {
      idUsuario: this.sessao?.id,
      Nome: this.form.value.nome,
      Email: this.form.value.email,
      Telefone: this.form.value.telefone,
    };

    this.clienteService.UpdateUsuario(dados).subscribe({
      next: () => {
        this.isLoading = false;
        this.editando = false;
        this.alert.toastSuccess('Perfil atualizado com sucesso!');
      },
      error: () => {
        this.isLoading = false;
        this.alert.toastError('Falha ao atualizar perfil.');
      },
    });
  }

  salvarSenha(): void {
    const { novaSenha, confirmarSenha, senhaAtual } = this.senhaForm.value;
    if (novaSenha !== confirmarSenha) {
      this.alert.toastWarning('As senhas não coincidem.');
      return;
    }
    this.isLoading = true;
    this.clienteService
      .UpdateSenhaUsuario({ idUsuario: this.sessao?.id, Senha: novaSenha })
      .subscribe({
        next: () => {
          this.isLoading = false;
          this.senhaForm.reset();
          this.alert.toastSuccess('Senha alterada com sucesso!');
        },
        error: () => {
          this.isLoading = false;
          this.alert.toastError('Falha ao alterar senha.');
        },
      });
  }

  logout(): void {
    this.auth.logout();
  }
}
