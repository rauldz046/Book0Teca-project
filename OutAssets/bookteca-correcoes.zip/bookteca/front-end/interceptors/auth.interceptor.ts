import { Injectable } from '@angular/core';
import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
  HttpErrorResponse,
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AuthService } from '../services/auth.service';
import { AlertService } from '../utils/toast-alert-service.service';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  constructor(private auth: AuthService, private alert: AlertService) {}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const token = this.auth.token;

    // Clona a requisição adicionando o token no header Authorization
    const reqAutenticado = token
      ? req.clone({
          setHeaders: { Authorization: `Bearer ${token}` },
        })
      : req;

    return next.handle(reqAutenticado).pipe(
      catchError((error: HttpErrorResponse) => {
        if (error.status === 401) {
          // Token expirado ou inválido → faz logout automático
          this.alert.toastWarning('Sessão expirada. Faça login novamente.');
          this.auth.logout();
        } else if (error.status === 403) {
          this.alert.toastError('Acesso negado.');
        } else if (error.status === 0) {
          this.alert.toastError('Servidor indisponível. Verifique sua conexão.');
        }
        return throwError(() => error);
      })
    );
  }
}
