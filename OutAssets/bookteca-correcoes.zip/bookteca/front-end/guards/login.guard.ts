import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

/**
 * Guard que impede acesso à tela de login quando o usuário já está autenticado.
 * Redireciona para /home se houver sessão ativa.
 *
 * Uso no routing:
 *   { path: 'auth/log-in', component: AuthLoginComponent, canActivate: [loginGuard] }
 */
export const loginGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (auth.estaLogado) {
    router.navigate(['/home']);
    return false;
  }

  return true;
};
