import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

/**
 * Guard que bloqueia rotas para usuários não autenticados.
 * Redireciona para /auth/log-in se não houver sessão ativa.
 *
 * Uso no routing:
 *   { path: 'home', component: HomeComponent, canActivate: [authGuard] }
 */
export const authGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (auth.estaLogado) {
    return true;
  }

  router.navigate(['/auth/log-in']);
  return false;
};
