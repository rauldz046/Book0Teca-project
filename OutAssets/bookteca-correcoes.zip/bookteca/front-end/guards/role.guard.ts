import { inject } from '@angular/core';
import { CanActivateFn, Router, ActivatedRouteSnapshot } from '@angular/router';
import { AuthService, UserProfile } from '../services/auth.service';

/**
 * Guard que bloqueia rotas para perfis sem permissão.
 * Deve ser usado JUNTO com authGuard (authGuard primeiro).
 *
 * Uso no routing — passe os perfis permitidos via data.roles:
 *   {
 *     path: 'relatorios/financeiro',
 *     component: GerenciamentoFinanceiroComponent,
 *     canActivate: [authGuard, roleGuard],
 *     data: { roles: ['FINANCEIRO', 'ADMINISTRADOR'] }
 *   }
 *
 * ADMINISTRADOR sempre tem acesso, independente da lista.
 */
export const roleGuard: CanActivateFn = (route: ActivatedRouteSnapshot) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  const perfisPermitidos: UserProfile[] = route.data['roles'] ?? [];

  if (auth.temPermissao(perfisPermitidos)) {
    return true;
  }

  // Redireciona para home com aviso de acesso negado via query param
  router.navigate(['/home'], { queryParams: { acessoNegado: true } });
  return false;
};
