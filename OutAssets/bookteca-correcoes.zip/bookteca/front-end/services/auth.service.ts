import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, tap } from 'rxjs';

export type UserProfile =
  | 'LEITOR'
  | 'BIBLIOTECARIO'
  | 'FINANCEIRO'
  | 'ESTOQUE'
  | 'ADMINISTRADOR';

export interface SessaoUsuario {
  id: number;
  nome: string;
  email: string;
  tipo: 'usuario' | 'funcionario';
  perfil: UserProfile;
  token: string;
  avatar?: string;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly URL = 'http://localhost:4000';
  private readonly SESSION_KEY = 'bookteca_session';

  private sessaoSubject = new BehaviorSubject<SessaoUsuario | null>(
    this.carregarSessao()
  );

  sessao$ = this.sessaoSubject.asObservable();

  private http = inject(HttpClient);
  private router = inject(Router);

  // ─── Getters ────────────────────────────────────────────────
  get sessaoAtual(): SessaoUsuario | null {
    return this.sessaoSubject.value;
  }

  get estaLogado(): boolean {
    return !!this.sessaoAtual;
  }

  get perfil(): UserProfile | null {
    return this.sessaoAtual?.perfil ?? null;
  }

  get token(): string | null {
    return this.sessaoAtual?.token ?? null;
  }

  get nomeUsuario(): string {
    return this.sessaoAtual?.nome ?? '';
  }

  // ─── Login de Usuário (Leitor) ───────────────────────────────
  loginUsuario(email: string, senha: string): Observable<any> {
    return this.http
      .post<any>(`${this.URL}/usuarios/login`, { email, senha })
      .pipe(
        tap((res) => {
          if (res) {
            // Mapeia o perfil do usuário — leitores sempre são LEITOR
            const sessao: SessaoUsuario = {
              id: res.idUsuario,
              nome: res.Nome,
              email: res.Email,
              tipo: 'usuario',
              perfil: 'LEITOR',
              token: res.token ?? this.gerarTokenSimples(res.idUsuario, 'usuario'),
              avatar: res.fotoperfil ?? undefined,
            };
            this.salvarSessao(sessao);
          }
        })
      );
  }

  // ─── Login de Funcionário ────────────────────────────────────
  loginFuncionario(email: string, senha: string): Observable<any> {
    return this.http
      .post<any>(`${this.URL}/funcionarios/login`, { email, senha })
      .pipe(
        tap((res) => {
          if (res) {
            // Mapeia o perfil com base no PerfilFuncionario vindo do back-end
            const perfilMap: Record<string, UserProfile> = {
              BIBLIOTECARIO: 'BIBLIOTECARIO',
              FINANCEIRO: 'FINANCEIRO',
              ESTOQUE: 'ESTOQUE',
              ADMINISTRADOR: 'ADMINISTRADOR',
            };
            const descricaoPerfil: string =
              res.perfil?.Descricao?.toUpperCase() ?? 'BIBLIOTECARIO';
            const sessao: SessaoUsuario = {
              id: res.idFuncionario,
              nome: res.NomeFunc,
              email: res.EmailFunc,
              tipo: 'funcionario',
              perfil: perfilMap[descricaoPerfil] ?? 'BIBLIOTECARIO',
              token: res.token ?? this.gerarTokenSimples(res.idFuncionario, 'funcionario'),
            };
            this.salvarSessao(sessao);
          }
        })
      );
  }

  // ─── Verificação de Permissão ────────────────────────────────
  temPermissao(perfisPermitidos: UserProfile[]): boolean {
    if (!this.perfil) return false;
    if (this.perfil === 'ADMINISTRADOR') return true;
    return perfisPermitidos.includes(this.perfil);
  }

  // ─── Logout ──────────────────────────────────────────────────
  logout(): void {
    localStorage.removeItem(this.SESSION_KEY);
    this.sessaoSubject.next(null);
    this.router.navigate(['/auth/log-in']);
  }

  // ─── Persistência ────────────────────────────────────────────
  private salvarSessao(sessao: SessaoUsuario): void {
    localStorage.setItem(this.SESSION_KEY, JSON.stringify(sessao));
    this.sessaoSubject.next(sessao);
  }

  private carregarSessao(): SessaoUsuario | null {
    try {
      const raw = localStorage.getItem(this.SESSION_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  }

  // Token simples enquanto o back-end não retorna JWT real
  private gerarTokenSimples(id: number, tipo: string): string {
    return btoa(`${tipo}:${id}:${Date.now()}`);
  }
}
