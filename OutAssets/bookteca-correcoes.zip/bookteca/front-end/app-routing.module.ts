import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { authGuard } from './guards/auth.guard';
import { roleGuard } from './guards/role.guard';
import { loginGuard } from './guards/login.guard';

// Auth
import { AuthLoginComponent } from './pages/auth-login/auth-login.component';
import { SignInFormUserComponent } from './pages/auth-login/sign-in-form-user/sign-in-form-user.component';

// Shared (todos os perfis logados)
import { HomeComponent } from './pages/home/home.component';
import { CatalogoComponent } from './pages/catalogo/catalogo.component';
import { UserPerfilComponent } from './pages/user-perfil/user-perfil.component';
import { PreferenciasComponent } from './pages/preferencias/preferencias.component';

// Usuário / Leitor
import { EmprestimosUsuariosComponent } from './pages/emprestimos-usuarios/emprestimos-usuarios.component';
import { DevolucaoUsuariosComponent } from './pages/devolucao-usuarios/devolucao-usuarios.component';
import { ReservasUsuariosComponent } from './pages/reservas-usuarios/reservas-usuarios.component';
import { GerenciarMultasUsuariosComponent } from './pages/gerenciar-multas-usuarios/gerenciar-multas-usuarios.component';
import { AtividadeUsuariosComponent } from './pages/atividade-usuarios/atividade-usuarios.component';

// Bibliotecário
import { GerenciarLeitoresComponent } from './pages/gerenciar-leitores/gerenciar-leitores.component';
import { GerenciarFuncionariosComponent } from './pages/gerenciar-funcionarios/gerenciar-funcionarios.component';
import { EmprestimosAtivosComponent } from './pages/emprestimos-ativos/emprestimos-ativos.component';

// Financeiro
import { GerenciamentoFinanceiroComponent } from './pages/gerenciamento-financeiro/gerenciamento-financeiro.component';

// Estoque
import { SaidaLivrosComponent } from './pages/saida-livros/saida-livros.component';

// Admin
import { GerenciarPermissoesComponent } from './pages/gerenciar-permissoes/gerenciar-permissoes.component';

const routes: Routes = [
  // ─── Redirecionar raiz ─────────────────────────────────────────
  { path: '', redirectTo: 'auth/log-in', pathMatch: 'full' },

  // ─── Rotas públicas (sem login) ────────────────────────────────
  {
    path: 'auth/log-in',
    component: AuthLoginComponent,
    canActivate: [loginGuard],
    data: { isLogin: true },
  },
  {
    path: 'auth/sign-in',
    component: SignInFormUserComponent,
    canActivate: [loginGuard],
    data: { isSignin: true },
  },

  // ─── Rotas compartilhadas (qualquer perfil logado) ─────────────
  {
    path: 'home',
    component: HomeComponent,
    canActivate: [authGuard],
    data: { titulo: 'Início' },
  },
  {
    path: 'acervo/livros',
    component: CatalogoComponent,
    canActivate: [authGuard],
    data: { titulo: 'Catálogo de Livros' },
  },
  {
    path: 'config/perfil',
    component: UserPerfilComponent,
    canActivate: [authGuard],
    data: { titulo: 'Meu Perfil' },
  },
  {
    path: 'config/preferencias',
    component: PreferenciasComponent,
    canActivate: [authGuard],
    data: { titulo: 'Preferências' },
  },

  // ─── Empréstimos / Devolução (Leitor + Bibliotecário) ──────────
  {
    path: 'emprestimos/ativos',
    component: EmprestimosUsuariosComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      titulo: 'Meus Empréstimos',
      roles: ['LEITOR', 'BIBLIOTECARIO'],
    },
  },
  {
    path: 'emprestimos/devolucoes',
    component: DevolucaoUsuariosComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      titulo: 'Devoluções',
      roles: ['BIBLIOTECARIO'],
    },
  },
  {
    path: 'emprestimos/reservas',
    component: ReservasUsuariosComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      titulo: 'Reservas de Livros',
      roles: ['LEITOR', 'BIBLIOTECARIO'],
    },
  },

  // ─── Multas (Leitor + Financeiro) ──────────────────────────────
  {
    path: 'multas/pendentes',
    component: GerenciarMultasUsuariosComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      titulo: 'Multas Pendentes',
      roles: ['LEITOR', 'FINANCEIRO'],
    },
  },
  {
    path: 'multas/atividade',
    component: AtividadeUsuariosComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      titulo: 'Minha Atividade',
      roles: ['LEITOR', 'BIBLIOTECARIO'],
    },
  },

  // ─── Usuários (Bibliotecário + Admin) ──────────────────────────
  {
    path: 'usuarios/leitores',
    component: GerenciarLeitoresComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      titulo: 'Leitores da BookOteca',
      roles: ['BIBLIOTECARIO'],
    },
  },
  {
    path: 'usuarios/funcionarios',
    component: GerenciarFuncionariosComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      titulo: 'Funcionários',
      roles: [], // apenas ADMINISTRADOR (lista vazia = só admin)
    },
  },

  // ─── Relatórios ────────────────────────────────────────────────
  {
    path: 'relatorios/emprestimos-ativos',
    component: EmprestimosAtivosComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      titulo: 'Empréstimos Ativos',
      roles: ['BIBLIOTECARIO'],
    },
  },
  {
    path: 'relatorios/saidas',
    component: SaidaLivrosComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      titulo: 'Saída de Livros',
      roles: ['ESTOQUE'],
    },
  },
  {
    path: 'relatorios/financeiro',
    component: GerenciamentoFinanceiroComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      titulo: 'Gerenciamento Financeiro',
      roles: ['FINANCEIRO'],
    },
  },

  // ─── Sistema (Admin only) ───────────────────────────────────────
  {
    path: 'sistema/permissoes',
    component: GerenciarPermissoesComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      titulo: 'Permissões do Sistema',
      roles: [], // apenas ADMINISTRADOR
    },
  },

  // ─── Fallback ───────────────────────────────────────────────────
  { path: '**', redirectTo: 'home' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
