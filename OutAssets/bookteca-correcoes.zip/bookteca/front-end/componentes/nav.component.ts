import { Component, inject, OnInit } from '@angular/core';
import { MenuItem, PrimeIcons } from 'primeng/api';
import { Router } from '@angular/router';
import { SidebarService } from '../responsive-sidebar.service';
import { AuthService, UserProfile } from 'src/app/services/auth.service';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.scss'],
})
export class NavComponent implements OnInit {
  items: MenuItem[] = [];
  collapsed = false;
  OptionSelected!: string;

  private readonly router = inject(Router);
  readonly sidebarService = inject(SidebarService);
  private readonly auth = inject(AuthService);

  // ─── Dados do usuário logado (vindos do AuthService) ─────────
  get userNome(): string {
    return this.auth.nomeUsuario;
  }

  get currentUserProfile(): UserProfile {
    return this.auth.perfil ?? 'LEITOR';
  }

  // ─── Dropdown de conta ────────────────────────────────────────
  usersDropdown = [
    { name: 'Perfil', code: '/config/perfil' },
    { name: 'Preferências', code: '/config/preferencias' },
    { name: 'Logout', code: '__logout__' },
  ];

  toggleSidebar() {
    this.sidebarService.toggle();
    this.collapsed = this.sidebarService.isCollapsed();
  }

  navigateOut(route: any): void {
    if (route.code === '__logout__') {
      this.auth.logout();
      return;
    }
    this.router.navigate([route.code]);
  }

  ngOnInit() {
    // Reage a mudanças na sessão (ex: login/logout em outra aba)
    this.auth.sessao$.subscribe(() => {
      this.items = this.generateMenu();
    });
  }

  hasPermission(allowedProfiles: UserProfile[]): boolean {
    return this.auth.temPermissao(allowedProfiles);
  }

  generateMenu(): MenuItem[] {
    const fullMenu = [
      {
        label: 'Usuários',
        icon: PrimeIcons.USERS,
        visible: this.hasPermission(['BIBLIOTECARIO']),
        items: [
          {
            label: 'Gerenciar Leitores',
            icon: PrimeIcons.USER,
            routerLink: '/usuarios/leitores',
            visible: this.hasPermission(['BIBLIOTECARIO']),
          },
          {
            label: 'Geren. Funcionários',
            icon: PrimeIcons.ID_CARD,
            routerLink: '/usuarios/funcionarios',
            visible: this.hasPermission([]), // Apenas Admin
          },
        ],
      },
      {
        label: 'Acervo',
        icon: PrimeIcons.BOOK,
        visible: true, // Todos veem o catálogo
        items: [
          {
            label: 'Catálogo',
            icon: PrimeIcons.BOOK,
            routerLink: '/acervo/livros',
            visible: true,
          },
          {
            label: 'Autores',
            icon: PrimeIcons.PENCIL,
            visible: this.hasPermission(['BIBLIOTECARIO', 'ESTOQUE']),
          },
        ],
      },
      {
        label: 'Empréstimos',
        icon: PrimeIcons.EXTERNAL_LINK,
        visible: this.hasPermission(['LEITOR', 'BIBLIOTECARIO']),
        items: [
          {
            label: 'Meus Empréstimos',
            icon: PrimeIcons.CALENDAR,
            routerLink: '/emprestimos/ativos',
            visible: this.hasPermission(['LEITOR']),
          },
          {
            label: 'Reservas',
            icon: PrimeIcons.BOOKMARK,
            routerLink: '/emprestimos/reservas',
            visible: this.hasPermission(['LEITOR', 'BIBLIOTECARIO']),
          },
          {
            label: 'Devoluções',
            icon: PrimeIcons.REFRESH,
            routerLink: '/emprestimos/devolucoes',
            visible: this.hasPermission(['BIBLIOTECARIO']),
          },
        ],
      },
      {
        label: 'Multas',
        icon: PrimeIcons.WALLET,
        visible: this.hasPermission(['LEITOR', 'FINANCEIRO']),
        items: [
          {
            label: 'Minhas Multas',
            icon: PrimeIcons.EXCLAMATION_TRIANGLE,
            routerLink: '/multas/pendentes',
            visible: this.hasPermission(['LEITOR', 'FINANCEIRO']),
          },
          {
            label: 'Atividade',
            icon: PrimeIcons.HISTORY,
            routerLink: '/multas/atividade',
            visible: this.hasPermission(['LEITOR', 'BIBLIOTECARIO']),
          },
        ],
      },
      {
        label: 'Relatórios',
        icon: PrimeIcons.CHART_BAR,
        visible: this.hasPermission(['BIBLIOTECARIO', 'FINANCEIRO', 'ESTOQUE']),
        items: [
          {
            label: 'Empréstimos Ativos',
            icon: PrimeIcons.CALENDAR,
            routerLink: '/relatorios/emprestimos-ativos',
            visible: this.hasPermission(['BIBLIOTECARIO']),
          },
          {
            label: 'Baixa de Livros',
            icon: PrimeIcons.CHART_LINE,
            routerLink: '/relatorios/saidas',
            visible: this.hasPermission(['ESTOQUE']),
          },
          {
            label: 'Financeiro',
            icon: PrimeIcons.DOLLAR,
            routerLink: '/relatorios/financeiro',
            visible: this.hasPermission(['FINANCEIRO']),
          },
        ],
      },
      {
        label: 'Inventário',
        icon: PrimeIcons.BOX,
        visible: this.hasPermission(['ESTOQUE', 'FINANCEIRO']),
        items: [
          {
            label: 'Estoque',
            icon: PrimeIcons.WALLET,
            routerLink: '/inventario/estoque',
            visible: this.hasPermission(['ESTOQUE']),
          },
          {
            label: 'Licitações',
            icon: PrimeIcons.PAPERCLIP,
            visible: this.hasPermission(['ESTOQUE']),
          },
          {
            label: 'Tesouraria',
            icon: PrimeIcons.DOLLAR,
            visible: this.hasPermission(['FINANCEIRO']),
          },
        ],
      },
      {
        label: 'Sistema',
        icon: PrimeIcons.SERVER,
        visible: this.hasPermission([]), // Apenas Admin
        items: [
          {
            label: 'Logs',
            icon: PrimeIcons.FILE,
            routerLink: '/sistema/logs',
          },
          {
            label: 'Permissões',
            icon: PrimeIcons.LOCK,
            routerLink: '/sistema/permissoes',
          },
        ],
      },
      {
        label: 'Configurações',
        icon: PrimeIcons.COG,
        visible: true,
        items: [
          {
            label: 'Perfil',
            icon: PrimeIcons.USER,
            routerLink: '/config/perfil',
          },
          {
            label: 'Preferências',
            icon: PrimeIcons.SLIDERS_H,
            routerLink: '/config/preferencias',
          },
        ],
      },
    ];

    return this.filterMenu(fullMenu);
  }

  filterMenu(menuItems: MenuItem[]): MenuItem[] {
    return menuItems
      .filter((item) => item.visible !== false)
      .map((item) => {
        if (item.items) {
          item.items = this.filterMenu(item.items);
        }
        return item;
      });
  }
}
