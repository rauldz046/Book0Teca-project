import { Component, inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/core/services/auth.service';
import { AlertService } from 'src/app/utils/toast-alert-service.service';

@Component({
  selector: 'app-auth-login',
  templateUrl: './auth-login.component.html',
  styleUrls: ['./auth-login.component.scss'],
})
export class AuthLoginComponent implements OnInit {
  private router = inject(Router);
  private auth = inject(AuthService);
  private alert = inject(AlertService);

  isLoading = false;

  form: FormGroup = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    senha: new FormControl('', [Validators.required, Validators.minLength(4)]),
  });

  ngOnInit(): void {
    // Se já estiver logado, redireciona direto para a home
    if (this.auth.estaLogado) {
      this.router.navigate(['/home']);
    }
  }

  goToSignIn(): void {
    this.router.navigate(['auth/sign-in']);
  }

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.isLoading = true;
    const { email, senha } = this.form.getRawValue();

    // Tenta login como usuário (leitor) primeiro
    this.auth.loginUsuario(email, senha).subscribe({
      next: (res) => {
        this.isLoading = false;
        if (res) {
          this.router.navigate(['/home']);
        } else {
          // Usuário não encontrado — tenta como funcionário
          this.tentarLoginFuncionario(email, senha);
        }
      },
      error: () => {
        // Erro na rota de usuário — tenta como funcionário
        this.tentarLoginFuncionario(email, senha);
      },
    });
  }

  private tentarLoginFuncionario(email: string, senha: string): void {
    this.auth.loginFuncionario(email, senha).subscribe({
      next: (res) => {
        this.isLoading = false;
        if (res) {
          this.router.navigate(['/home']);
        } else {
          this.alert.error('Login inválido', 'E-mail ou senha incorretos.');
        }
      },
      error: () => {
        this.isLoading = false;
        this.alert.error('Login inválido', 'E-mail ou senha incorretos.');
      },
    });
  }
}
