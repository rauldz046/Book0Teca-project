import { Component, inject, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs';
import { AuthService } from './core/services/auth.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  title = 'BookOTeca.com.br';

  userlogado = false;
  isLogin = false;
  isSignin = false;

  private router = inject(Router);
  readonly auth = inject(AuthService);

  ngOnInit(): void {
    this.router.events
      .pipe(filter((event) => event instanceof NavigationEnd))
      .subscribe(() => {
        // Percorre a árvore de rotas ativadas para pegar o data da rota atual
        let rota = this.router.routerState.root;
        while (rota.firstChild) rota = rota.firstChild;

        const data = rota.snapshot.data;

        this.userlogado = data['userlogado'] ?? true;
        this.isLogin = data['isLogin'] ?? false;
        this.isSignin = data['isSignin'] ?? false;
      });
  }
}
