import { Component, inject, OnInit } from '@angular/core';
import { MenuItem, PrimeIcons } from 'primeng/api';
import { Router } from '@angular/router';
import { SidebarService } from '../responsive-sidebar.service';
import { AuthService, UserProfile } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.scss'],
})
export class NavComponent implements OnInit {
  items: MenuItem[] = [];
  collapsed = false;
  OptionSelected!: string;

  private readonly router = inject(Router);
  readonly sidebarService = inject(SidebarService);
  readonly auth = inject(AuthService);

  // Dados do usuário vêm da sessão real
  get userNome(): string {
    return this.auth.nomeUsuario;
  }

  get currentUserProfile(): UserProfile {
    return this.auth.perfil ?? 'LEITOR';
  }

  usersDropdown = [
    { name: 'Meu Perfil', code: '/config/perfil' },
    { name: 'Preferências', code: '/config/preferencias' },
    { name: 'Sair', code: '__logout__' },
  ];

  toggleSidebar(): void {
    this.sidebarService.toggle();
  }

  navigateOut(route: { name: string; code: string }): void {
    if (route.code === '__logout__') {
      this.auth.logout();
      return;
    }
    this.router.navigate([route.code]);
    this.OptionSelected = this.userNome;
  }

  ngOnInit(): void {
    this.items = this.generateMenu();

    // Atualiza o menu quando a sessão mudar (ex: após login)
    this.auth.sessao$.subscribe(() => {
      this.items = this.generateMenu();
    });
  }

  hasPermission(allowedProfiles: UserProfile[]): boolean {
    if (this.currentUserProfile === 'ADMINISTRADOR') return true;
    if (allowedProfiles.length === 0) return false; // lista vazia = só admin
    return allowedProfiles.includes(this.currentUserProfile);
  }

  generateMenu(): MenuItem[] {
    const fullMenu: MenuItem[] = [
      {
        label: 'Usuários',
        icon: PrimeIcons.USERS,
        visible: this.hasPermission(['BIBLIOTECARIO']),
        items: [
          {
            label: 'Gerenciar Leitores',
            icon: PrimeIcons.USER,
            routerLink: '/usuarios/leitores',
            visible: this.hasPermission(['BIBLIOTECARIO']),
          },
          {
            label: 'Gerenciar Funcionários',
            icon: PrimeIcons.ID_CARD,
            routerLink: '/usuarios/funcionarios',
            visible: this.hasPermission([]), // Apenas Admin
          },
        ],
      },
      {
        label: 'Acervo',
        icon: PrimeIcons.BOOK,
        visible: true, // Todos veem o catálogo
        items: [
          {
            label: 'Catálogo',
            icon: PrimeIcons.BOOK,
            routerLink: '/acervo/livros',
            visible: true,
          },
          {
            label: 'Autores',
            icon: PrimeIcons.PENCIL,
            visible: this.hasPermission(['BIBLIOTECARIO', 'ESTOQUE']),
          },
        ],
      },
      {
        label: 'Empréstimos',
        icon: PrimeIcons.EXTERNAL_LINK,
        visible: this.hasPermission(['LEITOR', 'BIBLIOTECARIO']),
        items: [
          {
            label: 'Meus Empréstimos',
            icon: PrimeIcons.CALENDAR,
            routerLink: '/emprestimos/ativos',
            visible: this.hasPermission(['LEITOR', 'BIBLIOTECARIO']),
          },
          {
            label: 'Devoluções',
            icon: PrimeIcons.REFRESH,
            routerLink: '/emprestimos/devolucoes',
            visible: this.hasPermission(['BIBLIOTECARIO']),
          },
          {
            label: 'Reservas',
            icon: PrimeIcons.BOOKMARK,
            routerLink: '/emprestimos/reservas',
            visible: this.hasPermission(['LEITOR', 'BIBLIOTECARIO']),
          },
        ],
      },
      {
        label: 'Multas',
        icon: PrimeIcons.WALLET,
        visible: this.hasPermission(['LEITOR', 'FINANCEIRO', 'BIBLIOTECARIO']),
        items: [
          {
            label: 'Multas Pendentes',
            icon: PrimeIcons.EXCLAMATION_TRIANGLE,
            routerLink: '/multas/pendentes',
            visible: this.hasPermission(['LEITOR', 'FINANCEIRO', 'BIBLIOTECARIO']),
          },
          {
            label: 'Minha Atividade',
            icon: PrimeIcons.HISTORY,
            routerLink: '/multas/atividade',
            visible: this.hasPermission(['LEITOR', 'BIBLIOTECARIO']),
          },
        ],
      },
      {
        label: 'Relatórios',
        icon: PrimeIcons.CHART_BAR,
        visible: this.hasPermission(['BIBLIOTECARIO', 'FINANCEIRO', 'ESTOQUE']),
        items: [
          {
            label: 'Saída de Livros',
            icon: PrimeIcons.CHART_LINE,
            routerLink: '/relatorios/saidas',
            visible: this.hasPermission(['ESTOQUE', 'BIBLIOTECARIO']),
          },
          {
            label: 'Empréstimos Ativos',
            icon: PrimeIcons.CALENDAR,
            routerLink: '/relatorios/emprestimos-ativos',
            visible: this.hasPermission(['BIBLIOTECARIO']),
          },
          {
            label: 'Financeiro',
            icon: PrimeIcons.DOLLAR,
            routerLink: '/relatorios/financeiro',
            visible: this.hasPermission(['FINANCEIRO']),
          },
        ],
      },
      {
        label: 'Inventário',
        icon: PrimeIcons.BOX,
        visible: this.hasPermission(['ESTOQUE', 'FINANCEIRO']),
        items: [
          {
            label: 'Estoque',
            icon: PrimeIcons.WAREHOUSE,
            routerLink: '/inventario/estoque',
            visible: this.hasPermission(['ESTOQUE']),
          },
          {
            label: 'Tesouraria',
            icon: PrimeIcons.DOLLAR,
            routerLink: '/relatorios/financeiro',
            visible: this.hasPermission(['FINANCEIRO']),
          },
        ],
      },
      {
        label: 'Sistema',
        icon: PrimeIcons.SERVER,
        visible: this.hasPermission([]), // Apenas Admin
        items: [
          {
            label: 'Permissões',
            icon: PrimeIcons.LOCK,
            routerLink: '/sistema/permissoes',
          },
        ],
      },
      {
        label: 'Configurações',
        icon: PrimeIcons.COG,
        visible: true,
        items: [
          {
            label: 'Meu Perfil',
            icon: PrimeIcons.USER,
            routerLink: '/config/perfil',
          },
          {
            label: 'Preferências',
            icon: PrimeIcons.SLIDERS_H,
            routerLink: '/config/preferencias',
          },
        ],
      },
    ];

    return this.filterMenu(fullMenu);
  }

  filterMenu(menuItems: MenuItem[]): MenuItem[] {
    return menuItems
      .filter((item) => item['visible'] !== false)
      .map((item) => {
        if (item.items) {
          item.items = this.filterMenu(item.items);
        }
        return item;
      });
  }
}
