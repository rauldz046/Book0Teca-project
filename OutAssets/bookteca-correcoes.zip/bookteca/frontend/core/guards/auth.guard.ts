import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

/**
 * Guard de autenticação — impede acesso a qualquer rota protegida
 * sem uma sessão ativa. Redireciona para /auth/log-in se não logado.
 *
 * Uso no app-routing.module.ts:
 *   canActivate: [authGuard]
 */
export const authGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (auth.estaLogado) {
    return true;
  }

  router.navigate(['/auth/log-in']);
  return false;
};
