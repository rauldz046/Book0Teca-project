import { inject } from '@angular/core';
import { CanActivateFn, Router, ActivatedRouteSnapshot } from '@angular/router';
import { AuthService, UserProfile } from '../services/auth.service';

/**
 * Guard de perfil — verifica se o usuário logado tem permissão
 * para acessar a rota com base nos perfis definidos em `data.roles`.
 *
 * Uso no app-routing.module.ts:
 *   canActivate: [authGuard, roleGuard],
 *   data: { roles: ['FINANCEIRO', 'ADMINISTRADOR'] }
 *
 * Se `data.roles` não for definido, a rota é liberada para qualquer logado.
 */
export const roleGuard: CanActivateFn = (route: ActivatedRouteSnapshot) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  const rolesPermitidos: UserProfile[] = route.data?.['roles'] ?? [];

  // Se não definiu roles, qualquer autenticado pode acessar
  if (rolesPermitidos.length === 0) return true;

  if (auth.temPermissao(rolesPermitidos)) {
    return true;
  }

  // Usuário logado mas sem permissão — manda pra home
  router.navigate(['/home']);
  return false;
};
