import { Injectable, inject } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse,
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AuthService } from '../services/auth.service';
import { AlertService } from '../../utils/toast-alert-service.service';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  private auth = inject(AuthService);
  private alert = inject(AlertService);

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    const token = this.auth.token;

    // Clona a requisição adicionando o token no header Authorization
    const reqComToken = token
      ? req.clone({ setHeaders: { Authorization: `Bearer ${token}` } })
      : req;

    return next.handle(reqComToken).pipe(
      catchError((err: HttpErrorResponse) => {
        if (err.status === 401) {
          // Token expirado ou inválido — faz logout automático
          this.auth.logout();
          this.alert.error('Sessão expirada', 'Faça login novamente.');
        }

        if (err.status === 403) {
          this.alert.error('Acesso negado', 'Você não tem permissão para esta ação.');
        }

        if (err.status === 0) {
          this.alert.error('Servidor offline', 'Não foi possível conectar ao servidor.');
        }

        return throwError(() => err);
      })
    );
  }
}
