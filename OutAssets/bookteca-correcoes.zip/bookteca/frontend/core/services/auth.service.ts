import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, tap } from 'rxjs';

export type UserProfile =
  | 'LEITOR'
  | 'BIBLIOTECARIO'
  | 'FINANCEIRO'
  | 'ESTOQUE'
  | 'ADMINISTRADOR';

export interface SessaoUsuario {
  id: number;
  nome: string;
  email: string;
  perfil: UserProfile;
  tipo: 'usuario' | 'funcionario';
  token: string;
  fotoperfil?: string;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly SESSION_KEY = 'bookteca_sessao';
  private readonly url = 'http://localhost:4000/';

  private http = inject(HttpClient);
  private router = inject(Router);

  // BehaviorSubject expõe a sessão atual para todos os componentes
  private sessaoSubject = new BehaviorSubject<SessaoUsuario | null>(
    this.carregarSessao()
  );

  sessao$ = this.sessaoSubject.asObservable();

  // ─── Getters rápidos ───────────────────────────────────────────────────────

  get sessaoAtual(): SessaoUsuario | null {
    return this.sessaoSubject.value;
  }

  get estaLogado(): boolean {
    return !!this.sessaoAtual;
  }

  get perfil(): UserProfile | null {
    return this.sessaoAtual?.perfil ?? null;
  }

  get token(): string | null {
    return this.sessaoAtual?.token ?? null;
  }

  get nomeUsuario(): string {
    return this.sessaoAtual?.nome ?? '';
  }

  // ─── Login ─────────────────────────────────────────────────────────────────

  loginUsuario(email: string, senha: string): Observable<any> {
    return this.http
      .post<any>(`${this.url}usuarios/login`, { email, senha })
      .pipe(tap((res) => this.salvarSessao(res, 'usuario')));
  }

  loginFuncionario(email: string, senha: string): Observable<any> {
    return this.http
      .post<any>(`${this.url}funcionarios/login`, { email, senha })
      .pipe(tap((res) => this.salvarSessao(res, 'funcionario')));
  }

  // ─── Sessão ────────────────────────────────────────────────────────────────

  private salvarSessao(res: any, tipo: 'usuario' | 'funcionario'): void {
    if (!res) return;

    // Monta o perfil com base no tipo de conta
    let perfil: UserProfile = 'LEITOR';

    if (tipo === 'funcionario') {
      // O perfil vem do campo Descricao da tabela PerfilFuncionarios
      const descricao: string = res.perfil?.Descricao ?? '';
      perfil = this.mapearPerfil(descricao);
    }

    const sessao: SessaoUsuario = {
      id: res.idUsuario ?? res.idFuncionario,
      nome: res.Nome ?? res.NomeFunc,
      email: res.Email ?? res.EmailFunc,
      perfil,
      tipo,
      // O back-end ainda não gera JWT — usamos o id como token provisório
      // Quando adicionar JWT no back-end, troque por: res.token
      token: String(res.idUsuario ?? res.idFuncionario),
      fotoperfil: res.fotoperfil ?? undefined,
    };

    localStorage.setItem(this.SESSION_KEY, JSON.stringify(sessao));
    this.sessaoSubject.next(sessao);
  }

  private carregarSessao(): SessaoUsuario | null {
    try {
      const raw = localStorage.getItem(this.SESSION_KEY);
      return raw ? (JSON.parse(raw) as SessaoUsuario) : null;
    } catch {
      return null;
    }
  }

  logout(): void {
    localStorage.removeItem(this.SESSION_KEY);
    this.sessaoSubject.next(null);
    this.router.navigate(['/auth/log-in']);
  }

  // ─── Permissões ────────────────────────────────────────────────────────────

  temPermissao(perfisPermitidos: UserProfile[]): boolean {
    if (!this.perfil) return false;
    if (this.perfil === 'ADMINISTRADOR') return true;
    return perfisPermitidos.includes(this.perfil);
  }

  private mapearPerfil(descricao: string): UserProfile {
    const map: Record<string, UserProfile> = {
      BIBLIOTECARIO: 'BIBLIOTECARIO',
      FINANCEIRO: 'FINANCEIRO',
      ESTOQUE: 'ESTOQUE',
      ADMINISTRADOR: 'ADMINISTRADOR',
    };
    return map[descricao.toUpperCase()] ?? 'LEITOR';
  }
}
