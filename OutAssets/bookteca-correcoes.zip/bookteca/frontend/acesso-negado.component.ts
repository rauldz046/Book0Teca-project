import { Component, inject } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/core/services/auth.service';

@Component({
  selector: 'app-acesso-negado',
  template: `
    <div class="acesso-negado-container">
      <div class="acesso-negado-card">
        <i class="pi pi-lock icone"></i>
        <h1>Acesso Negado</h1>
        <p>
          Você não tem permissão para acessar esta página.<br />
          Perfil atual: <strong>{{ auth.perfil }}</strong>
        </p>
        <div class="acoes">
          <button
            pButton
            label="Voltar para Home"
            icon="pi pi-home"
            class="p-button-primary"
            (click)="irParaHome()"
          ></button>
          <button
            pButton
            label="Fazer Logout"
            icon="pi pi-sign-out"
            class="p-button-outlined p-button-danger"
            (click)="auth.logout()"
          ></button>
        </div>
      </div>
    </div>
  `,
  styles: [
    `
      .acesso-negado-container {
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 100vh;
        background: var(--surface-ground);
      }
      .acesso-negado-card {
        text-align: center;
        padding: 3rem;
        background: var(--surface-card);
        border-radius: 12px;
        box-shadow: 0 4px 24px rgba(0, 0, 0, 0.08);
        max-width: 420px;
      }
      .icone {
        font-size: 4rem;
        color: var(--red-500);
        margin-bottom: 1rem;
        display: block;
      }
      h1 {
        font-size: 1.8rem;
        font-weight: 600;
        margin-bottom: 1rem;
        color: var(--text-color);
      }
      p {
        color: var(--text-color-secondary);
        margin-bottom: 2rem;
        line-height: 1.6;
      }
      .acoes {
        display: flex;
        gap: 1rem;
        justify-content: center;
        flex-wrap: wrap;
      }
    `,
  ],
})
export class AcessoNegadoComponent {
  readonly auth = inject(AuthService);
  private router = inject(Router);

  irParaHome(): void {
    this.router.navigate(['/home']);
  }
}
