import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { authGuard } from './core/guards/auth.guard';
import { roleGuard } from './core/guards/role.guard';

import { AuthLoginComponent } from './pages/auth-login/auth-login.component';
import { SignInFormUserComponent } from './pages/auth-login/sign-in-form-user/sign-in-form-user.component';
import { HomeComponent } from './pages/home/home.component';
import { GerenciarLeitoresComponent } from './pages/gerenciar-leitores/gerenciar-leitores.component';
import { GerenciarFuncionariosComponent } from './pages/gerenciar-funcionarios/gerenciar-funcionarios.component';
import { CatalogoComponent } from './pages/catalogo/catalogo.component';
import { EmprestimosUsuariosComponent } from './pages/emprestimos-usuarios/emprestimos-usuarios.component';
import { DevolucaoUsuariosComponent } from './pages/devolucao-usuarios/devolucao-usuarios.component';
import { ReservasUsuariosComponent } from './pages/reservas-usuarios/reservas-usuarios.component';
import { GerenciarMultasUsuariosComponent } from './pages/gerenciar-multas-usuarios/gerenciar-multas-usuarios.component';
import { AtividadeUsuariosComponent } from './pages/atividade-usuarios/atividade-usuarios.component';
import { SaidaLivrosComponent } from './pages/saida-livros/saida-livros.component';
import { EmprestimosAtivosComponent } from './pages/emprestimos-ativos/emprestimos-ativos.component';
import { GerenciamentoFinanceiroComponent } from './pages/gerenciamento-financeiro/gerenciamento-financeiro.component';
import { UserPerfilComponent } from './pages/user-perfil/user-perfil.component';
import { GerenciarPermissoesComponent } from './pages/gerenciar-permissoes/gerenciar-permissoes.component';
import { PreferenciasComponent } from './pages/preferencias/preferencias.component';
import { AcessoNegadoComponent } from './pages/acesso-negado/acesso-negado.component';

const routes: Routes = [
  // ─── Rotas públicas (sem guard) ──────────────────────────────────────────
  {
    path: '',
    redirectTo: 'auth/log-in',
    pathMatch: 'full',
  },
  {
    path: 'auth/log-in',
    component: AuthLoginComponent,
    data: { userlogado: false, isLogin: true },
  },
  {
    path: 'auth/sign-in',
    component: SignInFormUserComponent,
    data: { userlogado: false, isSignin: true },
  },
  {
    path: 'acesso-negado',
    component: AcessoNegadoComponent,
    data: { userlogado: false },
  },

  // ─── Rotas autenticadas ──────────────────────────────────────────────────

  // Todos os perfis logados
  {
    path: 'home',
    component: HomeComponent,
    canActivate: [authGuard],
  },
  {
    path: 'config/perfil',
    component: UserPerfilComponent,
    canActivate: [authGuard],
    data: { titulo: 'Meu Perfil' },
  },
  {
    path: 'config/preferencias',
    component: PreferenciasComponent,
    canActivate: [authGuard],
    data: { titulo: 'Preferências' },
  },
  {
    path: 'acervo/livros',
    component: CatalogoComponent,
    canActivate: [authGuard],
    data: { titulo: 'Catálogo de Livros' },
  },

  // ─── LEITOR ──────────────────────────────────────────────────────────────
  {
    path: 'emprestimos/ativos',
    component: EmprestimosUsuariosComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      titulo: 'Meus Empréstimos',
      roles: ['LEITOR', 'BIBLIOTECARIO'],
    },
  },
  {
    path: 'multas/pendentes',
    component: GerenciarMultasUsuariosComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      titulo: 'Multas Pendentes',
      roles: ['LEITOR', 'FINANCEIRO', 'BIBLIOTECARIO'],
    },
  },
  {
    path: 'multas/atividade',
    component: AtividadeUsuariosComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      titulo: 'Minha Atividade',
      roles: ['LEITOR', 'BIBLIOTECARIO'],
    },
  },

  // ─── BIBLIOTECÁRIO ───────────────────────────────────────────────────────
  {
    path: 'usuarios/leitores',
    component: GerenciarLeitoresComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      titulo: 'Gerenciar Leitores',
      roles: ['BIBLIOTECARIO'],
    },
  },
  {
    path: 'emprestimos/devolucoes',
    component: DevolucaoUsuariosComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      titulo: 'Devoluções',
      roles: ['BIBLIOTECARIO'],
    },
  },
  {
    path: 'emprestimos/reservas',
    component: ReservasUsuariosComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      titulo: 'Reservas',
      roles: ['BIBLIOTECARIO', 'LEITOR'],
    },
  },
  {
    path: 'relatorios/emprestimos-ativos',
    component: EmprestimosAtivosComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      titulo: 'Empréstimos Ativos',
      roles: ['BIBLIOTECARIO'],
    },
  },

  // ─── FINANCEIRO ──────────────────────────────────────────────────────────
  {
    path: 'relatorios/financeiro',
    component: GerenciamentoFinanceiroComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      titulo: 'Gerenciamento Financeiro',
      roles: ['FINANCEIRO'],
    },
  },

  // ─── ESTOQUE ─────────────────────────────────────────────────────────────
  {
    path: 'relatorios/saidas',
    component: SaidaLivrosComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      titulo: 'Saída de Livros',
      roles: ['ESTOQUE', 'BIBLIOTECARIO'],
    },
  },

  // ─── ADMINISTRADOR ───────────────────────────────────────────────────────
  {
    path: 'usuarios/funcionarios',
    component: GerenciarFuncionariosComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      titulo: 'Gerenciar Funcionários',
      roles: ['ADMINISTRADOR'],
    },
  },
  {
    path: 'sistema/permissoes',
    component: GerenciarPermissoesComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      titulo: 'Permissões do Sistema',
      roles: ['ADMINISTRADOR'],
    },
  },

  // ─── Fallback ─────────────────────────────────────────────────────────────
  { path: '**', redirectTo: 'auth/log-in' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
